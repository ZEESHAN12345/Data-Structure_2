import java.util.Scanner;
                                // main class starts from here
public class stack_permutation {
	                                        // main function starts from here
	public static void main(String args[]) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter the length of your input sequence:");
		int n = input.nextInt();
		
		int data[] = new int[n];
		
		System.out.println("Please enter the digits of your input sequence one-by-one:");
		
		SinglyLinkedList list1 = new SinglyLinkedList();
		queue I = new queue();                                //creating input stack I
		
		for( int i=0; i<n; i++ ) {                           //filling the input stack I
			data[i] = input.nextInt();
			I.enqueue(list1, i+1);
		}
		
		SinglyLinkedList list2 = new SinglyLinkedList();
		stack S = new stack();                               //creating Stack S
		
		SinglyLinkedList list3 = new SinglyLinkedList();
		queue O = new queue();                               //creating output queue O
		int i= 0;
		String print = "";
		boolean state = true;
		int temp = 0;
		
		while( i < n) {                              
			
			if ( !I.isEmpty(list1) ) {
				
				if( I.first(list1) == data[i] ) {             // checking and enqueue in output queue O by dequeue from Queue I
				
				O.enqueue( list3, I.dequeue(list1) );
				print = print + "enqueue(O, dequeue(I))"+"\n" ;
				i++;
				temp = 1;
				continue;
				}
				temp = 0;
			}
			
			
			if( !I.isEmpty(list1) ) {                       // checking and pushing in Stack S by dequeue from input stack I
				
				S.push( list2, I.dequeue(list1) );            
				print = print + "push(S, dequeue(I))" + "\n";
				temp = 1;
				continue;
				}
		        temp = 0;
			
		        
		   if ( !S.isEmpty(list2) ) {                      // checking and enqueue in output queue O by popping from Stack S
			 
				if ( S.top(list2) == data[i] ) {
					
				O.enqueue( list3, S.pop(list2) );
				print = print + "enqueue(O, pop(S))" + "\n";
				i++;
				temp = 1;
				continue;
				}
				
               if ( S.top(list2) != data[i] && temp == 0 ) {     // checking and printing if the given sequence is not a stack permutation with the specified reason 
					
					System.out.println("Sorry ! Input sequence is not a stack permutation.");
					System.out.print("Reason: " + "The following part of your sequence, i.e.,");
					for( int j=i; j<n ; j++) {
						System.out.print(" " + data[j] + " ");
					}
					System.out.println(" is not in the order that stack permutaion needs to be after some prior operations.");
					state = false;
					break;
					
				}
				
			}
			
		
			}
		
		if (state == true) {                        // printing the sequence if given Sequence is a stack permutation
			System.out.println("Yes! Given sequence of numbers is a stack permutation, with the following sequence of stack operations: ");
			System.out.println();
			System.out.println(print);
		}
			
		}
		
	}

                        // Singly Linked List code starts from here
class SinglyLinkedList {

	Object singly_node;
	singly_node root;
	singly_node temp;
	singly_node curr;
	int size = 0;
	
	public void addNodes(int put_data) {
		
		singly_node node = new singly_node(put_data);
		if (root == null) {
			root = node;
			root.nextNode = null;
		}
			
			else {
				curr = root;
				while (curr.nextNode!=null) {
					curr = curr.nextNode;
				}
				curr.nextNode = node;
				node.nextNode = null;
					
			}
		size++;
	}
	
	public int size(){
		return size;
	}
	
	public void print() {
		
		curr = root;
		while(curr!=null) {
			System.out.print(curr.data+" ");
			curr = curr.nextNode;
		}
			
		
	}
	
}                 // Singly Linked List code ends here

                   //Node of Singly Linked List code starts from here
class singly_node {
	int noOfLinkedList = 0;
	int data;
	
	singly_node nextNode;
	
	singly_node(int data) {
		this.data = data;
		noOfLinkedList++;
	}
}                //Node of Singly Linked List code ends here

             //Stack (made using Singly Linked List) code starts from here 
class stack {
	
	public int size(SinglyLinkedList list) {
		
		int count = 0;
		singly_node n = new singly_node(0);
		n.nextNode = list.root;
		n = n.nextNode;
		
		while( n.nextNode !=null ) {
			n = n.nextNode;
			count++;
		}
		int size = count+1;
		
		return size;
	}
	
	public boolean isEmpty(SinglyLinkedList list) {
		
		singly_node n = new singly_node(0);
		n.nextNode = list.root;
		n = n.nextNode;
		
		if( n == null)
		return true;
		
		else
			return false;
	}
	
	public void push( SinglyLinkedList list, int put_data ) {
	    list.addNodes(put_data);
	}
	
	public int pop( SinglyLinkedList list ) {
		
		int count =0;
		
		singly_node n1 = new singly_node(0);
		n1.nextNode = list.root;
		n1 = n1.nextNode;
		
		singly_node n2 = new singly_node(0);
		n2.nextNode = list.root;
		n2 = n2.nextNode;
		
		while( n1.nextNode !=null )  {
			n1 = n1.nextNode;
			count++;
		}
		int result=n1.data;
		
		for(int i=1 ; i<count; i++) {
			n2 = n2.nextNode;
		}
		n2.nextNode = null;
		
        return result;
		
	}
	
	public int top( SinglyLinkedList list ) {
		
		if( list.size ==0)
			return 0;
		
		else {
			
		singly_node n = new singly_node(0);
		n = list.root;
		
		while( n.nextNode !=null ) {
			n = n.nextNode;
		}
		int result = n.data;
		
		return result;
		
		}
		
	}
	
	
}          //Stack code ends here


             //Queue (made using Singly Linked List) code starts from here 
class queue {
	
public int size(SinglyLinkedList list) {
		
		int count = 0;
		singly_node n = new singly_node(0);
		n.nextNode = list.root;
		n = n.nextNode;
		
		while( n.nextNode !=null ) {
			n = n.nextNode;
			count++;
		}
		int size = count+1;
		
		return size; 
	}


public boolean isEmpty(SinglyLinkedList list) {
	
	singly_node n = new singly_node(0);
	n.nextNode = list.root;
	n = n.nextNode;
	
	if( n == null)
	return true;
	
	else
		return false;
    }

                       
public void enqueue(SinglyLinkedList list, int put_data) {
	
	if( list.size == 0 ) 
		list.addNodes(put_data);
	
	else
	list.addNodes(put_data);
	
}


public int dequeue( SinglyLinkedList list ) {
	
	singly_node n = new singly_node(0);
	n = list.root;
	int result = n.data;
	list.root = n.nextNode; 
	
	return result;
	
}


public int first( SinglyLinkedList list ) {
	
	singly_node n = new singly_node(0);
	n.nextNode = list.root;
	n = n.nextNode;
	
	int result = n.data;
	
	return result;
	
}

}         //Queue code ends here 