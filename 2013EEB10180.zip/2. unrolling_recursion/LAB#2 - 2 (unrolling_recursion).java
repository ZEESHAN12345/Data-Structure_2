import java.util.Scanner;

                                  // main class starts from here //
public class unrolling_recursion {
	                                    // main function starts from here // 
public static void main(String args[]) {
	
	int n;
	int k;
	String s;
	
	Scanner input=new Scanner(System.in);
	
	System.out.println("Please enter the value of Integer 'n' for sum of n integers:");
	n=input.nextInt();
	
	input.nextLine();
	
	System.out.println("Please enter the value of Integer 'k' for k-th Fobonacci number:");
	k=input.nextInt();
	
	input.nextLine();
	
	System.out.println("Please enter the String 's':");
	s=input.nextLine();
	
	System.out.println();
	
	System.out.print("Sum of first '"+n+"' integers (solved in recursive fashion) is: ");
	System.out.println( sum_recursion(n, 0) );
	System.out.println();
	
	System.out.print("'"+k+"-th' "+"no. of Fibonacci series (solved in mutilple recursive fashion) is: ");
	System.out.println( Fib_recursion(k, 1, 2, 1) );
	System.out.println();
	
	System.out.print("Given String is ");
	int len=s.length();
	if (pali_recursion(s, len, 0))
		System.out.println("a palindrome (solved in recursive fashion)");
	else
		System.out.println("not a palindrome (solved in recursive fashion)");
	System.out.println();
	
	System.out.print("Sum of first '"+n+"' integers (solved using stacks and loops via 'snapshot' class' objects) is: ");
	System.out.println( sum_stacks(n) );
	System.out.println();
	
	System.out.print("'"+k+"-th' "+"no. of Fibonacci series (solved using stacks and loops via 'snapshot' class' objects) is: ");
	System.out.println( fib_stacks(k) );
	System.out.println();
	
	System.out.print("Given String is ");
	if ( pali_stacks(s) )
		System.out.println("a palindrome (solved using stacks and loops via 'snapshot' class' objects)");
	else
		System.out.println("not a palindrome (solved using stacks and loops via 'snapshot' class' objects)");
	System.out.println();
	
}


/** recursive functions starts from here **/

                                                                          // recursive 'sum' function starts from here //
static int sum_recursion(int n, int sum) throws IllegalArgumentException {
	
	if(n<0)
		throw new IllegalArgumentException();
	
	else if(n==0)
		return sum;
	
	else {
		    sum += n ;
		    
		    n--;
			
		    return sum_recursion(n, sum);
		}
	
	}

                                                                                      // recursive 'Fibonacci' series function starts from here //
static int Fib_recursion(int k, int f, int F, int i) throws IllegalArgumentException {
	
	if(k<0)
		throw new IllegalArgumentException();
	
	else if(k==0)
		return 0;
	
	else if( k==1 || k==2)
		return 1;
	
	else if( k>2 && i<k-2 ) {
		
		int temp =f;
		
		f = F;
		
		F = temp + F;
		
		i++;
		
		return Fib_recursion(k, f, F, i) ;
		
	     }
	
	else
		return F;
}


                                                         // recursive 'Palindrome' function starts from here //
static boolean pali_recursion(String s, int len, int i) {
	
	if( s.charAt(i)==s.charAt(len-1) && i<=len ) {
		
	    	i += 1;
	    	
		    len -= 1;
		    
			return pali_recursion(s, len, i);
	}
	
	else if(s.charAt(i)==s.charAt(len-1) && i>len)
		return true;
	
	else
	   return false;
}


/** stack functions starts from here **/

                                // stack 'sum' function starts from here //
static int sum_stacks( int k ) {
	
	myRecursionSnapshot_sum snapSum = new myRecursionSnapshot_sum();
	stack_MOD s = new stack_MOD();
	SinglyLinkedList_MOD list = new SinglyLinkedList_MOD();
	
	int n = 1;
	snapSum.set_n(n);
	s.push( list, snapSum );
    int sum = 0;
    
	while ( n <= k ) {
		
		sum = sum + s.pop(list).get_n();
		n++;
		snapSum.set_n(n);
		s.push(list, snapSum);
	}	
	return sum;
	
}

                                // stack 'Fibonacci' function starts from here //                         
static int fib_stacks( int k ) {
	
	myRecursionSnapshot_Fib snapFib = new myRecursionSnapshot_Fib();
	stack_MOD2 s = new stack_MOD2();
	SinglyLinkedList_MOD2 list = new SinglyLinkedList_MOD2();
	
	int F = 2;
	snapFib.set_F(F);
	int f = 1;
	snapFib.set_f(f);
	int temp = 0;
	snapFib.set_temp(temp);
	int i = 1;
	snapFib.set_i(i);
	
	if( k==0 ) {
		return 0;
	}
	
	if( k==1 || k ==2 ) {
		return 1;
	}
	
	while ( i < k-2 ) {
		
		temp = f;
		snapFib.set_temp(temp);
		
		f = F;
		snapFib.set_f(f);
		
		F = f+ temp;
		snapFib.set_F(F);
		
		i++;
		s.push( list, snapFib );      //object of Fibonacci's Snapshot class is pushed into the stack
		
	}
	
	return s.pop(list).get_F();
	
}

                                          // stack 'Palindrome' function starts from here//
static boolean pali_stacks( String str ) {
	
	myRecursionSnapshot_pali snapPali = new myRecursionSnapshot_pali();
	
	stack_MOD3 s = new stack_MOD3();
	SinglyLinkedList_MOD3 list = new  SinglyLinkedList_MOD3();
	
	int len = str.length();
	snapPali.set_len(len);
	int i = 0;
	snapPali.set_i(i);
	
	while ( str.charAt(i)==str.charAt(len-1) && i <= len-1 ) {
		
		s.push( list, snapPali );
		i++;
		snapPali.set_i(i);
		len--;
		snapPali.set_len(len);
		
	}
	
	if ( i > len-1 )
		return true;
	
	else
		return false;

}

}


/** Snapshot classes starts from here **/

                               // snapshot class for 'sum' function starts from here //
class myRecursionSnapshot_sum {
	
	private int sum;
	private int n;
	private int stage;
	
	public myRecursionSnapshot_sum() {
	
	                                 }
	
	public myRecursionSnapshot_sum(int sum, int n, int stage) {
		
		this.sum  = sum;
		this.n = n;
		this.stage = stage;
		
    }
	
	public int get_sum() {
		return sum;
	}
	
   public int get_n() {
		return n;
	}
   
   public int getStage() {
	   return stage;
   }
	
   
   public void set_sum(int sum) {
	   this.sum = sum;
   }
   
   public void set_n(int n) {
	   this.n = n;
   }
   
   public void setStage(int stage) {
	   this.stage = stage;
   }

}

                               //snapshot class for 'Fibonacci series' function starts from here //
class myRecursionSnapshot_Fib {
	
	private int f;
	private int F;
	private int i;
	private int temp;
	private int stage;
	
	public myRecursionSnapshot_Fib() {
	
	                                 }
	
	public myRecursionSnapshot_Fib(int f, int F, int i, int temp, int stage) {
		
		this.f  = f;
		this.F = F;
		this.i = i;
		this.temp = temp;
		this.stage = stage;
		
    }
	
	public int get_f() {
		return f;
	}
	
   public int get_F() {
		return F;
	}
   
   public int get_i() {
		return i;
	}
   
   public int get_temp() {
		return temp;
	}
   
   public int getStage() {
	   return stage;
   }
	
   
   public void set_f(int f) {
	   this.f = f;
   }
   
   public void set_F(int F) {
	   this.F = F;
   }
   
   public void set_i(int i) {
	   this.i = i;
   }
   
   public void set_temp(int temp) {
	   this.temp = temp;
   }
   
   public void setStage(int stage) {
	   this.stage = stage;
   }
   
}

                                //snapshot class for 'Palindrome' function starts from here //
class myRecursionSnapshot_pali {
	
	private int s;
	private int len;
	private int i;
	private int temp;
	private int stage;
	
	public myRecursionSnapshot_pali() {
	
	                                 }
	
	public myRecursionSnapshot_pali(int s, int len, int i, int temp, int stage) {
		
		this.s  = s;
		this.len = len;
		this.i = i;
		this.temp =temp;
		this.stage = stage;
		
    }
	
	public int get_s() {
		return s;
	}
	
   public int get_len() {
		return len;
	}
   
   public int get_i() {
		return i;
	}
   
   public int get_temp() {
		return temp;
	}
   
   public int getStage() {
	   return stage;
   }
	
   
   public void set_s(int s) {
	   this.s = s;
   }
   
   public void set_len(int len) {
	   this.len = len;
   }
   
   public void set_i(int i) {
	   this.i = i;
   }
   
   public void set_temp(int temp) {
	   this.temp = temp;
   }
   
   public void setStage(int stage) {
	   this.stage = stage;
   }
   
}


                            /** stack for 'sum' class (using Singly Linked List) starts from here**/
class SinglyLinkedList_MOD {

	Object singly_node_MOD;
	singly_node_MOD root;
	singly_node_MOD temp;
	singly_node_MOD curr;
	int size = 0;
	
	public void addNodes(myRecursionSnapshot_sum put_data) {
		
		singly_node_MOD node = new singly_node_MOD(put_data);
		if (root == null) {
			root = node;
			root.nextNode = null;
		}
			
			else {
				curr = root;
				while (curr.nextNode!=null) {
					curr = curr.nextNode;
				}
				curr.nextNode = node;
				node.nextNode = null;
					
			}
		size++;
	}
	
}


class singly_node_MOD {
	myRecursionSnapshot_sum data;
	
	singly_node_MOD nextNode;
	
	singly_node_MOD(myRecursionSnapshot_sum data) {
		this.data = data;
	}
}


class stack_MOD {
	
	public boolean isEmpty(SinglyLinkedList_MOD list) {
		
		singly_node_MOD n = new singly_node_MOD(null);
		/**n.nextNode = list.root;
		n = n.nextNode;**/
		n = list.root;
		
		if( n == null)
		return true;
		
		else
			return false;
	}
	
	public void push( SinglyLinkedList_MOD list, myRecursionSnapshot_sum put_data ) {
	    list.addNodes(put_data);
	}
	
	public myRecursionSnapshot_sum pop( SinglyLinkedList_MOD list ) {
		
		int count =0;
		
		singly_node_MOD n1 = new singly_node_MOD(null);
		n1.nextNode = list.root;
		n1 = n1.nextNode;
		
		singly_node_MOD n2 = new singly_node_MOD(null);
		n2.nextNode = list.root;
		n2 = n2.nextNode;
		
		while( n1.nextNode !=null )  {
			n1 = n1.nextNode;
			count++;
		}
	
		myRecursionSnapshot_sum result=n1.data;
		
		for(int i=1 ; i<count; i++) {
			n2 = n2.nextNode;
		}
		n2.nextNode = null;
		
        return result;
		
	}
	
}


                             /** stack for 'Fibonacci series' class (using Singly Linked List) starts from here**/
class SinglyLinkedList_MOD2 {

	Object singly_node_MOD2;
	singly_node_MOD2 root;
	singly_node_MOD2 temp;
	singly_node_MOD2 curr;
	int size = 0;
	
	public void addNodes(myRecursionSnapshot_Fib put_data) {
		
		singly_node_MOD2 node = new singly_node_MOD2(put_data);
		if (root == null) {
			root = node;
			root.nextNode = null;
		}
			
			else {
				curr = root;
				while (curr.nextNode!=null) {
					curr = curr.nextNode;
				}
				curr.nextNode = node;
				node.nextNode = null;
					
			}
		size++;
	}
	
}


class singly_node_MOD2 {
	myRecursionSnapshot_Fib data;
	
	singly_node_MOD2 nextNode;
	
	singly_node_MOD2(myRecursionSnapshot_Fib data) {
		this.data = data;
	}
}


class stack_MOD2 {
	
	public boolean isEmpty(SinglyLinkedList_MOD2 list) {
		
		singly_node_MOD2 n = new singly_node_MOD2(null);
		n.nextNode = list.root;
		n = n.nextNode;
		
		if( n == null)
		return true;
		
		else
			return false;
	}
	
	public void push( SinglyLinkedList_MOD2 list, myRecursionSnapshot_Fib put_data ) {
	    list.addNodes(put_data);
	}
	
	public myRecursionSnapshot_Fib pop( SinglyLinkedList_MOD2 list ) {
		
		int count =0;
		
		singly_node_MOD2 n1 = new singly_node_MOD2(null);
		n1.nextNode = list.root;
		n1 = n1.nextNode;
		
		singly_node_MOD2 n2 = new singly_node_MOD2(null);
		n2.nextNode = list.root;
		n2 = n2.nextNode;
		
		while( n1.nextNode !=null )  {
			n1 = n1.nextNode;
			count++;
		}
		myRecursionSnapshot_Fib result=n1.data;
		
		for(int i=1 ; i<count; i++) {
			n2 = n2.nextNode;
		}
		n2.nextNode = null;
		
        return result;
		
	}
	
}

                             /** stack for 'Palindrome' class (using Singly Linked List) starts from here **/
class SinglyLinkedList_MOD3 {

	Object singly_node_MOD3;
	singly_node_MOD3 root;
	singly_node_MOD3 temp;
	singly_node_MOD3 curr;
	int size = 0;
	
	public void addNodes(myRecursionSnapshot_pali put_data) {
		
		singly_node_MOD3 node = new singly_node_MOD3(put_data);
		if (root == null) {
			root = node;
			root.nextNode = null;
		}
			
			else {
				curr = root;
				while (curr.nextNode!=null) {
					curr = curr.nextNode;
				}
				curr.nextNode = node;
				node.nextNode = null;
					
			}
		size++;
	}
	
}


class singly_node_MOD3 {
	myRecursionSnapshot_pali data;
	
	singly_node_MOD3 nextNode;
	
	singly_node_MOD3(myRecursionSnapshot_pali data) {
		this.data = data;
	}
}


class stack_MOD3 {
	
	public boolean isEmpty(SinglyLinkedList_MOD3 list) {
		
		singly_node_MOD3 n = new singly_node_MOD3(null);
		n.nextNode = list.root;
		n = n.nextNode;
		
		if( n == null)
		return true;
		
		else
			return false;
	}
	
	public void push( SinglyLinkedList_MOD3 list, myRecursionSnapshot_pali put_data ) {
	    list.addNodes(put_data);
	}
	
	public myRecursionSnapshot_pali pop( SinglyLinkedList_MOD3 list ) {
		
		int count =0;
		
		singly_node_MOD3 n1 = new singly_node_MOD3(null);
		n1.nextNode = list.root;
		n1 = n1.nextNode;
		
		singly_node_MOD3 n2 = new singly_node_MOD3(null);
		n2.nextNode = list.root;
		n2 = n2.nextNode;
		
		while( n1.nextNode !=null )  {
			n1 = n1.nextNode;
			count++;
		}
		myRecursionSnapshot_pali result=n1.data;
		
		for(int i=1 ; i<count; i++) {
			n2 = n2.nextNode;
		}
		n2.nextNode = null;
		
        return result;
		
	}
	
}