import java.util.Scanner;

                            /**main class starts from here**/
public class ext_int_arith {
	                                   /**main method starts from here**/
public static void main(String[] args) {
	String s1;
	String s2;
	String s3;
	Scanner input=new Scanner(System.in);
	System.out.println("Please enter the Extended Integer 1 in a continuous string format");
	s1=input.nextLine();
	System.out.println("Please enter the operation you want to perform over Extended Integer inputs");
	s2=input.nextLine();
	System.out.println("Please enter the Extended Integer 2 in a continuous string format");
	s3=input.nextLine();
	
	int l1=s1.length();
	int l3=s3.length();
	String s1_final="";
	String s3_final="";
	int diff=Math.abs(l1-l3);
	
	if(l1>l3) {
		String temp=s3;
		for (int i=0;i<diff;i++) {
			s3_final="0" + temp;
			temp=s3_final;
		}
		s1_final=s1;
	}
	
	else if(l3>l1) {
		String temp=s1;
		for (int i=0;i<diff;i++) {
			s1_final="0" + temp;
			temp=s1_final;
		}
		s3_final=s3;
	}
	
	else {
		s1_final=s1;
		s3_final=s3;
	}
	
	char[] c1=s1_final.toCharArray();
	char[] c3=s3_final.toCharArray();
	String str1 = String.valueOf(c1);
	String str3 = String.valueOf(c3);
	
/** creating and filling the two Linked Lists two Extended integer inputs **/
	
	DoublyLinkedList list1 = new DoublyLinkedList();
	DoublyLinkedList list2 = new DoublyLinkedList();
	
	for (int x=0;x<c1.length;x++) {
		list1.addNodes(Character.getNumericValue(c1[x]));
	}

	for (int y=0;y<c3.length;y++) {
		list2.addNodes(Character.getNumericValue(c3[y]));
	}
	input.close();
	 
/** calling each function depending on the operation that user inputs **/
	
if(s2.equals("+")) {
	add(c1.length, list1, list2);
}

else if(s2.equals("-")) {
	subtract(c1. length, list1, list2, s1, s3);
}

else if(s2.equals("*")) {
	multiply(s1, s3, list1, list2);
}

else if(s2.equals("/")) {
	divide(c1.length, list1, list2, str1, str3);
}

else if(s2.equals("<")) {
	if(less_than(c1.length, s1, s3, list1, list2))
		System.out.println("Yes! Extended Integer 1 is less than Extended Integer 2");
		else
			System.out.println("No! Extended Integer 1 is not less than Extended Integer 2");
}

else if(s2.equals(">")) {
	if(greater_than(c1.length, s1, s3, list1, list2))
		System.out.println("Yes! Extended Integer 1 is greater than Extended Integer 2");
		else
			System.out.println("No! Extended Integer 1 is not greater than Extended Integer 2");
}

else if(s2.equals("==")) {
	if(equals_to(c1.length, s1, s3, list1, list2))
		System.out.println("Yes! Extended Integer 1 is equal to Extended Integer 2");
		else
			System.out.println("No! Extended Integer 1 is not equal to Extended Integer 2");
}

else if(s2.equals(">=")) {
	if(greater_equals_to(c1.length, s1, s3, list1, list2))
		System.out.println("Yes! Extended Integer 1 is greater than or equals to Extended Integer 2");
		else
			System.out.println("No! Extended Integer 1 is not greater than or equals to Extended Integer 2");
}

else if(s2.equals("<=")) {
	if(less_equals_to(c1.length, s1, s3, list1, list2))
		System.out.println("Yes! Extended Integer 1 is less than or equals to Extended Integer 2");
		else
			System.out.println("No! Extended Integer 1 is not less than or equals to Extended Integer 2");
}

else {
	System.out.println("Sorry! entered operation is not permitted!");
}

}


                                                                    /** 'addition' function starts from here**/
static void add(int len, DoublyLinkedList d1, DoublyLinkedList d2) {
	
	int temp[]=new int[len+1];
	int sum=0;
	int carry=0;
	node n1=new node(0);
	n1.prevNode=d1.end;
	n1=n1.prevNode;
	node n2=new node(0);
	n2.prevNode=d2.end;
	n2=n2.prevNode;
	
	for(int i=len;i>0;i--) {
		
		sum= n1.data + n2.data + carry;
		if(sum>9) {
			char [] chars = String.valueOf(sum).toCharArray();
			temp[i]=Character.getNumericValue( chars[1] );
			carry=Character.getNumericValue( chars[0] );
		}
		
		else {
			temp[i]=sum;
			carry=0;
		}
		sum=0;
		n1=n1.prevNode;
		n2=n2.prevNode;
	}

	DoublyLinkedList list3 = new DoublyLinkedList();
	
	for(int k=0;k<(len+1);k++) {
		
		if(k==0) {
			
			if(carry==0)
				continue;
			else
				list3.addNodes(carry);
		}
		
		else 
			list3.addNodes(temp[k]);
	}
	
	list3.print();

}


                                                                                               /** 'subtraction' function starts from here**/
static void subtract(int len, DoublyLinkedList d1, DoublyLinkedList d2, String s1, String s3) {
	
	int diff = 0;
    int borrow = 0;
    int upper = 0;
    
    node n1 = new node(0);
	n1.prevNode = d1.end;
	n1 = n1.prevNode;
	
	node n2 = new node(0);
	n2.prevNode = d2.end;
	n2 = n2.prevNode;
	
	int temp[] = new int[len];
	
	DoublyLinkedList list3 = new DoublyLinkedList();
	
	if( greater_equals_to(len, s1, s3, d1, d2) ) {
		
	for(int i = len; i > 0; i--) {
		
		if( (n1.data) > n2.data) {
			
			   if (n1.data == 0 && borrow!=0) {
				upper = 9;
				diff = upper - n2.data;
				borrow = 1;
			     }
			
			   else {
				upper = n1.data - borrow;
				diff = upper - n2.data;
				borrow = 0;
			        }
			    	
			}
		
		else if( n1.data == n2.data) {
			
			if (n1.data!=0 && borrow!=0) {
				n1.data = n1.data - borrow;
				upper = Integer.parseInt( "1"+ String.valueOf(n1.data) );
				diff = upper - n2.data;
				borrow = 1;
			     }
			
			if (n1.data!=0 && borrow==0) {
				upper = n1.data;
				diff = upper - n2.data;
				borrow = 0;
		        }
			
			
			if (n1.data == 0 && borrow!=0) {
				upper = 9;
				diff = upper - n2.data;
				borrow = 1;
			     }
			
			if (n1.data==0 && borrow==0) {
				upper = n1.data;
				diff = upper - n2.data;
				borrow = 0;
		        }
		}
		
		else {
			
			if (n1.data == 0 && borrow!=0) {
				upper = 9;
				diff = upper - n2.data;
				borrow = 1;
			     }
			
			else {
				upper = Integer.parseInt( "1"+ String.valueOf( n1.data - borrow) );
				diff = upper - n2.data;
				borrow = 1;
			     }
			
		}
		
		temp[i-1] = diff;
		diff = 0;
		
		n1 = n1.prevNode;
		n2 = n2.prevNode;
	}
	
	for (int j=0; j<len; j++) {
		list3.addNodes(temp[j]);
	}
	
	list3.print();
	
	}
	
	
	else {
		
		for(int i = len; i > 0; i--) {
			
			if( (n2.data) > n1.data) {
				
				   if (n2.data == 0 && borrow!=0) {
					upper = 9;
					diff = upper - n1.data;
					borrow = 1;
				     }
				
				   else {
					upper = n2.data - borrow;
					diff = upper - n1.data;
					borrow = 0;
				        }
				    	
				}
			
			else if( n2.data == n1.data) {
				
				if (n2.data!=0 && borrow!=0) {
					n2.data = n2.data - borrow;
					upper = Integer.parseInt( "1"+ String.valueOf(n2.data) );
					diff = upper - n1.data;
					borrow = 1;
				     }
				
				if (n1.data!=0 && borrow==0) {
					upper = n2.data;
					diff = upper - n1.data;
					borrow = 0;
			        }
				
				
				if (n2.data == 0 && borrow!=0) {
					upper = 9;
					diff = upper - n1.data;
					borrow = 1;
				     }
				
				if (n2.data==0 && borrow==0) {
					upper = n2.data;
					diff = upper - n1.data;
					borrow = 0;
			        }
			}
			
			else {
				
				if (n2.data == 0 && borrow!=0) {
					upper = 9;
					diff = upper - n1.data;
					borrow = 1;
				     }
				
				else {
					upper = Integer.parseInt( "1"+ String.valueOf( n2.data - borrow) );
					diff = upper - n1.data;
					borrow = 1;
				     }
				
			}
			
			temp[i-1] = diff;
			diff = 0;
			
			n1 = n1.prevNode;
			n2 = n2.prevNode;
		}
		
		for (int j=0; j<len; j++) {
			list3.addNodes(temp[j]);
		}
		
		System.out.print("-");
		list3.print();
		
	}
	
}

                                                                                      /**'multiplication' function starts from here**/
static void multiply(String s1, String s3, DoublyLinkedList d1, DoublyLinkedList d2) {
	
	int len1 = s1.length();
	int len2 = s3.length();
	
	node n1 = new node(0);
	n1 = d1.end;
	
	node n2 = new node(0);
	n2 = d2.end;
	int multiply;
	
	int t = 2;
	
	int final_multiply_array [][] = new int[len2][len1+len2];
	
	DoublyLinkedList list4 = new DoublyLinkedList();
	for(int k=0; k<( (len1 + t) -1); k++)
			list4.addNodes(0);
	
	int x = 0;
	
	for ( int j = len2-1; j>=0; j--) {
		
		int carry = 0;
		int [] temp = new int [len1 +  len2];
		
		for( int i = len1-1; i>=0; i--) {
			
			multiply = n2.data * n1.data + carry;
			int z = len2 + i - x;
			
			if(multiply>9) {
				
				char [] chars = String.valueOf(multiply).toCharArray();
				temp[z] = Character.getNumericValue( chars[1] );
				carry = Character.getNumericValue( chars[0] );
			}
			
			else {
	
				temp[z] = multiply;
				carry = 0;
			}
			
			n1 = n1.prevNode;
			
		}
		    
		    n1 = d1.end;
		    
		    for (int k=0; k<len1+len2; k++) {
		    
		    	if( k == j ) 
		    		final_multiply_array [x][k] = carry;
		    	else
		            final_multiply_array [x][k] = temp [k];
		    
		    }
		
		x++;
		t++;
		n2 = n2.prevNode;
		
	}
	
	int carry = 0;
	int [] temp = new int[len1 + len2];
	
	    for( int c= (len1+len2)-1 ; c>=0; c-- ) {
	    	
	      int sum = 0;
	      
			for ( int r=0; r<len2; r++ ) {
				
		sum = sum + final_multiply_array [r][c];
		
		     }
			
		sum = sum + carry;
		int final_sum = sum;
		
		if ( final_sum>9 && c!=0) {
			
		char [] chars = String.valueOf(sum).toCharArray();
		char temp_sum = chars[ chars.length - 1 ];
		sum = (int)(temp_sum - '0');
		temp[c] = sum;
        char [] chars_final = new char [chars.length-1];
		for(int i=0; i<chars.length-1; i++) {
			chars_final[i] = chars[i];
		        }
		String str = String.valueOf(chars_final);
		carry = Integer.parseInt(str);
		
		}
		
		if ( final_sum<=9 && c!=0 ){
			
			temp[c] = sum;
		    carry = 0;
		
		}
		
		if( c==0 )
			temp [c] = sum;
		
	}
	
	DoublyLinkedList list = new DoublyLinkedList();
	for ( int l = 0; l < len1 + len2; l++)
		list.addNodes(temp[l]);
		
	list.print();
	
}
                                                                                                 /**'division' function starts from here**/
static void divide(int len, DoublyLinkedList d1, DoublyLinkedList d2, String str1, String str3) {
	
	int quotient;
	int counter = 0;
	
	int diff = 0;
    int borrow = 0;
    int upper = 0;
    
    node n1 = new node(0); 
	n1 =d1.end;
	
	node n2 = new node(0);
	n2 = d2.end;
	
    int temp[] = new int[len];
	DoublyLinkedList list3 = new DoublyLinkedList();
	
	while( greater_equals_to(len, str1, str3, d1, d2) ) {
		
		for(int i = len; i > 0; i--) {
			
			if( (n1.data) > n2.data) {
				
				   if (n1.data == 0 && borrow!=0) {
					upper = 9;
					diff = upper - n2.data;
					borrow = 1;
				     }
				
				   else {
					upper = n1.data - borrow;
					diff = upper - n2.data;
					borrow = 0;
				        }
				    	
				}
			
			else if( n1.data == n2.data) {
				
				if (n1.data!=0 && borrow!=0) {
					n1.data = n1.data - borrow;
					upper = Integer.parseInt( "1"+ String.valueOf(n1.data) );
					diff = upper - n2.data;
					borrow = 1;
				     }
				
				if (n1.data!=0 && borrow==0) {
					upper = n1.data;
					diff = upper - n2.data;
					borrow = 0;
			        }
				
				
				if (n1.data == 0 && borrow!=0) {
					upper = 9;
					diff = upper - n2.data;
					borrow = 1;
				     }
				
				if (n1.data==0 && borrow==0) {
					upper = n1.data;
					diff = upper - n2.data;
					borrow = 0;
			        }
			}
			
			else {
				
				if (n1.data == 0 && borrow!=0) {
					upper = 9;
					diff = upper - n2.data;
					borrow = 1;
				     }
				
				else {
					upper = Integer.parseInt( "1"+ String.valueOf( n1.data - borrow) );
					diff = upper - n2.data;
					borrow = 1;
				     }
				
			}
			
			temp[i-1] = diff;
			diff = 0;
			
			n1 = n1.prevNode;
			n2 = n2.prevNode;
		}
		
		n1=d1.root;
		for (int j=0; j<len; j++) {
			
			n1.data = temp[j];
			n1 = n1.nextNode;
		}
		
		n1 = d1.end;
		n2 = d2.end;
		
		str1 = "";
		for(int k=0; k<len; k++) {
			str1 = str1 + String.valueOf(temp[k]);
		}
		
		counter++;
		
	}
	
	
	if ( less_than(len, str1, str3, d1, d2) ) {
		
		quotient = counter;
		System.out.print("Quotient is : ");
		System.out.println(counter);
		System.out.print("Remainder is : ");
		d1.print();
		
	}
	
}
                                                                                                   /**comparison function 'less_than' starts from here**/
static boolean less_than(int len, String s1, String s3, DoublyLinkedList d1, DoublyLinkedList d2) {
	
	node n1 = new node(0);
	n1.nextNode = d1.root;
	n1 = n1.nextNode;
	
	node n2 = new node(0);
	n2.nextNode = d2.root;
	n2 = n2.nextNode;
		
		for(int i=0; i<len; i++) {
			
        if( i==len-1 )
		    if( n1.data==n2.data )
				return false;
			
		if( n1.data<n2.data ) {
			return true;
		}
		
		else if( n1.data==n2.data && i!=len-1 ) {
			n1 = n1.nextNode;
			n2 = n2.nextNode;
		}
		
		else {
			return false;
		}
		
		}
		return true;
		
}
                                                                                                      /**comparison function  'greater_than' starts from here**/
static boolean greater_than(int len, String s1, String s3, DoublyLinkedList d1, DoublyLinkedList d2) {
	
	node n1 = new node(0);
	n1.nextNode = d1.root;
	n1 = n1.nextNode;
	
	node n2 = new node(0);
	n2.nextNode = d2.root;
	n2 = n2.nextNode;
		
		for(int i=0; i<len; i++) {
			
	        if( i==len-1 )
			    if( n1.data==n2.data )
					return false;
				
			if( n1.data>n2.data ) {
				return true;
			}
			
			else if( n1.data==n2.data && i!=len-1 ) {
				n1 = n1.nextNode;
				n2 = n2.nextNode;
			}
			
			else {
				return false;
			}
			
			}
			return true;
	
}
                                                /**equality comparison function 'equals_to' starts from here**/
static boolean equals_to( int len, String s1, String s3, DoublyLinkedList d1, DoublyLinkedList d2 ) {

		if( greater_than(len, s1, s3, d1, d2) || less_than(len, s1, s3, d1, d2) ) {
			return false;
		}
		else {
			return true;
		}
}
                                                                                                           /**comparison function 'greater_equals_to' starts from here**/
static boolean greater_equals_to(int len, String s1, String s3, DoublyLinkedList d1, DoublyLinkedList d2) {
	if( greater_than(len, s1, s3, d1, d2) || equals_to(len, s1, s3, d1, d2) )
   return true;
	else
		return false;
}
                                                                                                        /**comparison function 'less_equals_to' starts from here**/
static boolean less_equals_to(int len, String s1, String s3, DoublyLinkedList d1, DoublyLinkedList d2) {
	if( less_than(len, s1, s3, d1, d2) || equals_to(len, s1, s3, d1, d2) )
	return true;
	else 
		return false;
}

}


                        /**DoublyLinkedList code stars from here**/
class DoublyLinkedList {
     public Object node;
	 node root;
	 node temp;
	 node curr;
	 node end;
	 
	 
                                      /**function to add a node in a Doubly Linked list, starts from here**/
	public void addNodes(int dstore) {
		node node = new node(dstore);
		if(root==null){
			root = node;
			root.nextNode = null;
			root.prevNode = null;
			end=node;
			}
		else {
			curr = root;
			while(curr.nextNode!=null) {
				curr = curr.nextNode;
			}
			curr.nextNode = node;
			node.nextNode = null;
			node.prevNode = curr;
			end=node;
			}
		}
	
	
       public void print(){
		
    	   curr = root;
    	   
    	   while(curr!=null) {
		
			System.out.print(curr.data);
			
			curr = curr.nextNode;
    	   }
		}
       
}


            /**DoublyLinkedList's node code starts from here**/
class node {
    int noOfLinkedList = 0;
	int data;
	
	node prevNode;
	node nextNode;
	
	node(int data) {
		this.data = data;
		noOfLinkedList++;
	}
}

                                           /**DoublyLinkedList code ends here**/